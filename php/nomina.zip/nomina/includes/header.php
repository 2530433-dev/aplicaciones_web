<html>
    <head>
        <title><?php echo $titulo; ?></title>
        <link rel="stylesheet" href="nomina/styles.css">
    </head>
    <body>
        <main>
            <h1><?php echo $titulo; ?></h1>